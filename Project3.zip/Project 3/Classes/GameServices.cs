﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Project_3.Classes
{
    /// <summary>
    /// leads the War game:dealing, playing rounds, tie handling, and victory.
    /// </summary>
    public sealed class GameService
    {
        /// <summary>all players and their hands</summary>
        public PlayerHands Players { get; } = new PlayerHands();

        /// <summary>Cards currently revealed on the table</summary>
        public PlayedCards Table { get; } = new PlayedCards();

        /// <summary>cards at stake across ties winner eventually takes all</summary>
        private readonly List<Card> _bounty = new List<Card>();

        /// <summary>
        /// starts a new game validates player count creates a random deck
        /// and deals cards evenly into player queues
        /// </summary>
        /// <param name="playerNames">between 2 and 4 player names</param>
        /// <exception cref="ArgumentException">thrown if player count is not 2–4</exception>
        public void StartNewGame(params string[] playerNames)
        {
            if (playerNames == null || playerNames.Length < 2 || playerNames.Length > 4)
                throw new ArgumentException("Game supports 2–4 players.");

            Players.Hands.Clear();
            foreach (var n in playerNames) Players.AddPlayer(n);

            var deck = new Deck();
            int i = 0;

            // deal out all 52 cards roundrobin to player queues
            while (deck.Any)
            {
                var name = playerNames[i % playerNames.Length];
                Players.Hands[name].AddToBottom(deck.Draw());
                i++;
            }

            Table.Clear();
            _bounty.Clear();
        }

        /// <summary>
        /// true when only one player still has cards winner is returned via out param
        /// </summary>
        /// <param name="winnerName">name of the winner if the game is over otherwise null</param>
        public bool IsGameOver(out string winnerName)
        {
            var stillIn = Players.Hands
                .Where(kv => kv.Value.HasCards)
                .Select(kv => kv.Key)
                .ToList();

            if (stillIn.Count == 1)
            {
                winnerName = stillIn[0];
                return true;
            }

            winnerName = null;
            return false;
        }

        /// <summary>
        /// plays one reveal per active player on tei cards carry into bounty and
        /// the method returns null the next call resolves when a single winner appears
        /// </summary>
        /// <returns>the winner of the resolved reveal or null on a tie</returns>
        public string PlayRound()
        {
            Table.Clear();

            // everyone who can reveals one card
            foreach (var kv in Players.Hands.ToList())
            {
                var name = kv.Key;
                var hand = kv.Value;
                if (hand.HasCards)
                    Table.Play(name, hand.PlayTopCard());
            }

            // all revealed cards go into the bounty pot
            _bounty.AddRange(Table.AllCards());

            // highest rank determines the leaders
            var maxRank = Table.Table.Max(kv => kv.Value.Rank);
            var leaders = Table.Table
                .Where(kv => kv.Value.Rank == maxRank)
                .Select(kv => kv.Key)
                .ToList();

            // tie: keep bounty and return null to continue next round
            if (leaders.Count != 1)
                return null;

            // single winner takes the entire bounty to the bottom of their hand
            var winner = leaders[0];
            Players.Hands[winner].AddToBottom(_bounty);
            _bounty.Clear();
            return winner;
        }
    }
}
