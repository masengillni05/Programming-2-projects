﻿using System;
using System.Collections.Generic;

namespace Project_3.Classes
{
    /// <summary>
    /// a deck backed by a stack&ltCard&gt bulds 52 random cards duplicates allowed.
    /// </summary>
    public sealed class Deck
    {
        /// <summary>random number generator used forr card selection</summary>
        private readonly Random _rng = new Random();

        /// <summary>all cards remaining in the deck top is the next pop()</summary>
        public Stack<Card> Cards { get; } = new Stack<Card>();

        /// <summary>
        /// builds a deck of 52 randomly generated cards. duplicates are allowed by design.
        /// </summary>
        public Deck()
        {
            for (int i = 0; i < 52; i++)
            {
                var suit = (Suit)_rng.Next(0, 4);
                int[] ranks = { 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14 };
                var rank = (Rank)ranks[_rng.Next(0, ranks.Length)];
                Cards.Push(new Card(suit, rank));
            }
        }

        /// <summary>true if at least one card remains</summary>
        public bool Any => Cards.Count > 0;

        /// <summary>removes and returns the top card</summary>
        public Card Draw() => Cards.Pop();
    }
}

