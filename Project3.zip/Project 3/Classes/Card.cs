﻿using System;

namespace Project_3.Classes
{
    /// <summary>all four suits in a standard deck</summary>
    public enum Suit { Hearts, Diamonds, Clubs, Spades }

    /// <summary>ranks from two low to ace high</summary>
    public enum Rank
    {
        Two = 2, Three, Four, Five, Six, Seven, Eight, Nine, Ten,
        Jack = 11, Queen = 12, King = 13, Ace = 14
    }

    /// <summary>
    /// a single playing card cmompares by rank so higher rank wins.
    /// </summary>
    public sealed class Card : IComparable<Card>
    {
        /// <summary>the cards suit (Hearts, Diamonds, Clubs, Spades)</summary>
        public Suit Suit { get; }

        /// <summary>the cards rank (two through ace)</summary>
        public Rank Rank { get; }

        /// <summary>creates a card with the given suit and rank</summary>
        /// <param name="suit">suit of the card</param>
        /// <param name="rank">rank of the card</param>
        public Card(Suit suit, Rank rank)
        {
            Suit = suit;
            Rank = rank;
        }

        /// <summary>compares two cards by rank</summary>
        /// <param name="other">another card to compare to</param>
        /// <returns> negative if lowerr zero if equal positive if higher</returns>
        public int CompareTo(Card other) => Rank.CompareTo(other.Rank);

        /// <summary>readable text like “Ace of Spades”eee</summary>
        public override string ToString() => $"{Rank} of {Suit}";
    }
}
