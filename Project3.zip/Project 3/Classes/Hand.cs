﻿using System.Collections.Generic;

namespace Project_3.Classes
{
    /// <summary>
    /// a players hand backed by a queue&ltcard&gt dequeue to play enqueue to collect.
    /// </summary>
    public sealed class Hand
    {
        /// <summary>Queue of cards front is the next to be played</summary>
        public Queue<Card> Queue { get; } = new Queue<Card>();

        /// <summary>how many cards are currently in the hand</summary>
        public int Count => Queue.Count;

        /// <summary>true if the hand still has at least one card</summary>
        public bool HasCards => Queue.Count > 0;

        /// <summary>removes and returns the top card to play this round</summary>
        public Card PlayTopCard() => Queue.Dequeue();

        /// <summary>adds a single card to the bottom of the hand</summary>
        public void AddToBottom(Card card) => Queue.Enqueue(card);

        /// <summary>adds a set of cards to the bottom of the hand winner takes all</summary>
        public void AddToBottom(IEnumerable<Card> cards)
        {
            foreach (var c in cards) Queue.Enqueue(c);
        }
    }
}
