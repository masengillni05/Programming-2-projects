﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections.Generic;

namespace Project_3.Classes
{
    /// <summary>
    /// all players in the match mapping player name to their hand
    /// </summary>
    public sealed class PlayerHands
    {
        /// <summary>dictionary of player name to hand</summary>
        public Dictionary<string, Hand> Hands { get; } = new Dictionary<string, Hand>();

        /// <summary>adds or replaces a player with a fresh empty hand</summary>
        /// <param name="name">Player’s display name</param>
        public void AddPlayer(string name) => Hands[name] = new Hand();

        /// <summary>tries to get a players hand by name</summary>
        public bool TryGetHand(string name, out Hand hand) => Hands.TryGetValue(name, out hand);

        /// <summary>all player names currently in the game.</summary>
        public IEnumerable<string> Players => Hands.Keys;

        /// <summary>number of players in the dictionary.</summary>
        public int Count => Hands.Count;

        /// <summary>indexer to access a hand by name.</summary>
        public Hand this[string name]
        {
            get => Hands[name];
            set => Hands[name] = value;
        }
    }
}
