﻿using System.Collections.Generic;

namespace Project_3.Classes
{
    /// <summary>
    /// cards on the table for the current reveal one per active player.
    /// </summary>
    public sealed class PlayedCards
    {
        /// <summary>player name card they played this reveal</summary>
        public Dictionary<string, Card> Table { get; } = new Dictionary<string, Card>();

        /// <summary>records or updates the card a player just revealed</summary>
        /// <param name="playerName">name of the player</param>
        /// <param name="card">card played this reveal</param>
        public void Play(string playerName, Card card) => Table[playerName] = card;

        /// <summary>celears the table for the next reveal</summary>
        public void Clear() => Table.Clear();

        /// <summary>returns an enumerable of all cards on the table</summary>
        public IEnumerable<Card> AllCards() => Table.Values;
    }
}
