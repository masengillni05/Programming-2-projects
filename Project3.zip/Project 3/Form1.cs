﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Project_3.Classes;

namespace Project_3
{
    /// <summary>
    /// Main GUI for the War game. Lets the user pick player count/names,
    /// start a match, play rounds, and see results update live.
    /// </summary>
    public partial class Form1 : Form
    {
        /// <summary>Game engine that manages dealing, rounds, and victory.</summary>
        private GameService _game = new GameService();

        /// <summary>Current number of players selected in the UI (2–4).</summary>
        private int _playerCount = 2;

        /// <summary>
        /// Initializes the form and sets initial control state.
        /// </summary>
        public Form1()
        {
            InitializeComponent();

            // Seed combo if the designer ever loses items.
            if (cmbPlayers.Items.Count == 0)
                cmbPlayers.Items.AddRange(new object[] { 2, 3, 4 });
            cmbPlayers.SelectedIndex = 0;

            TogglePlayerInputs();
            SetActionButtons(false);
            UpdateCountLabelsClear();
        }

        // ----------------- UI helpers -----------------

        /// <summary>
        /// Shows or hides Player 3/4 controls to match the selected player count.
        /// </summary>
        private void TogglePlayerInputs()
        {
            _playerCount = int.TryParse(Convert.ToString(cmbPlayers.SelectedItem), out var n) ? n : 2;

            // 3rd player visibility
            bool show3 = _playerCount >= 3;
            lblName3.Visible = show3;
            txtP3.Visible = show3;
            lblP3.Visible = show3;

            // 4th player visibility
            bool show4 = _playerCount >= 4;
            lblName4.Visible = show4;
            txtP4.Visible = show4;
            lblP4.Visible = show4;
        }

        /// <summary>
        /// Enables or disables the game action buttons.
        /// </summary>
        /// <param name="on">True to enable, false to disable.</param>
        private void SetActionButtons(bool on)
        {
            btnPlay.Enabled = on;
            btnAuto10.Enabled = on;
            btnReset.Enabled = on;
        }

        /// <summary>
        /// Builds the current list of player names from text boxes,
        /// filling in defaults if a box is empty.
        /// </summary>
        /// <returns>Array of player names in order.</returns>
        private string[] CurrentNames()
        {
            var list = new List<string>
            {
                ValueOrDefault(txtP1, "Player 1"),
                ValueOrDefault(txtP2, "Player 2")
            };
            if (_playerCount >= 3) list.Add(ValueOrDefault(txtP3, "Player 3"));
            if (_playerCount >= 4) list.Add(ValueOrDefault(txtP4, "Player 4"));
            return list.ToArray();
        }

        /// <summary>
        /// Returns trimmed text or a default if the box is empty.
        /// </summary>
        private static string ValueOrDefault(TextBox tb, string dflt)
        {
            var s = tb.Text == null ? "" : tb.Text.Trim();
            return string.IsNullOrEmpty(s) ? dflt : s;
        }

        /// <summary>
        /// Refreshes the count labels to show how many cards each player has.
        /// </summary>
        private void UpdateCounts()
        {
            var names = CurrentNames();

            lblP1.Text = $"{names[0]}: {GetHandCount(names[0])}";
            lblP2.Text = $"{names[1]}: {GetHandCount(names[1])}";

            if (_playerCount >= 3)
                lblP3.Text = $"{names[2]}: {GetHandCount(names[2])}";
            if (_playerCount >= 4)
                lblP4.Text = $"{names[3]}: {GetHandCount(names[3])}";
        }

        /// <summary>
        /// Looks up a hand by player name and returns its size as text.
        /// </summary>
        private string GetHandCount(string name)
        {
            Hand h;
            return _game.Players.TryGetHand(name, out h) ? h.Count.ToString() : "0";
        }

        /// <summary>
        /// Resets all count labels to zeros (used at startup/reset).
        /// </summary>
        private void UpdateCountLabelsClear()
        {
            lblP1.Text = "Player 1: 0";
            lblP2.Text = "Player 2: 0";
            lblP3.Text = "Player 3: 0";
            lblP4.Text = "Player 4: 0";
        }

        /// <summary>
        /// Appends this reveal’s played cards and result (tie or winner) to the log.
        /// </summary>
        /// <param name="roundWinner">Name of the round winner, or null on tie.</param>
        private void LogTable(string roundWinner)
        {
            foreach (var kv in _game.Table.Table)
                lstRound.Items.Add($"{kv.Key} played {kv.Value}");

            if (roundWinner == null)
                lstRound.Items.Add("Tie! Cards carried to bounty. Play again.");
            else
                lstRound.Items.Add($"Winner: {roundWinner} (takes the bounty)");

            lstRound.Items.Add(new string('-', 40));
            lstRound.TopIndex = lstRound.Items.Count - 1;
        }

        /// <summary>
        /// Shows a game-over message and disables actions once one player wins everything.
        /// </summary>
        private void CheckForGameOver()
        {
            string winner;
            if (_game.IsGameOver(out winner))
            {
                MessageBox.Show($"{winner} wins the game and has all the cards!", "Game Over");
                SetActionButtons(false);
            }
        }

        // ----------------- Events -----------------

        /// <summary>
        /// When the user changes 2/3/4 players, show/hide the extra inputs.
        /// </summary>
        private void cmbPlayers_SelectedIndexChanged(object sender, EventArgs e)
        {
            TogglePlayerInputs();
        }

        /// <summary>
        /// Starts a fresh game: deals a random 52-card deck evenly to players.
        /// </summary>
        private void btnStart_Click(object sender, EventArgs e)
        {
            var names = CurrentNames();
            _game = new GameService(); // fresh engine each start
            _game.StartNewGame(names);

            lstRound.Items.Clear();
            SetActionButtons(true);
            UpdateCounts();

            MessageBox.Show($"Game started with {names.Length} players.", "War");
        }

        /// <summary>
        /// Plays one reveal for each active player and logs the outcome.
        /// </summary>
        private void btnPlay_Click(object sender, EventArgs e)
        {
            var winner = _game.PlayRound();
            LogTable(winner);
            UpdateCounts();
            CheckForGameOver();
        }

        /// <summary>
        /// Plays ten reveals in a row (or stops early if someone already won).
        /// </summary>
        private void btnAuto10_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 10; i++)
            {
                string dummy;
                if (_game.IsGameOver(out dummy)) break;

                var winner = _game.PlayRound();
                LogTable(winner);
            }
            UpdateCounts();
            CheckForGameOver();
        }

        /// <summary>
        /// Clears the round log and disables actions, keeping the current player setup.
        /// </summary>
        private void btnReset_Click(object sender, EventArgs e)
        {
            lstRound.Items.Clear();
            SetActionButtons(false);
            UpdateCountLabelsClear();
        }
    }
}

