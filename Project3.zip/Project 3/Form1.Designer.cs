﻿namespace Project_3
{
    partial class Form1
    {
        /// <summary>
        /// required  for designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// cleans up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// required method for d55esigner support.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPlayersCaption = new System.Windows.Forms.Label();
            this.cmbPlayers = new System.Windows.Forms.ComboBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnPlay = new System.Windows.Forms.Button();
            this.btnAuto10 = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.lblName1 = new System.Windows.Forms.Label();
            this.txtP1 = new System.Windows.Forms.TextBox();
            this.lblP1 = new System.Windows.Forms.Label();
            this.lblName2 = new System.Windows.Forms.Label();
            this.txtP2 = new System.Windows.Forms.TextBox();
            this.lblP2 = new System.Windows.Forms.Label();
            this.lblName3 = new System.Windows.Forms.Label();
            this.txtP3 = new System.Windows.Forms.TextBox();
            this.lblP3 = new System.Windows.Forms.Label();
            this.lblName4 = new System.Windows.Forms.Label();
            this.txtP4 = new System.Windows.Forms.TextBox();
            this.lblP4 = new System.Windows.Forms.Label();
            this.lblLogCaption = new System.Windows.Forms.Label();
            this.lstRound = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lblPlayersCaption
            // 
            this.lblPlayersCaption.AutoSize = true;
            this.lblPlayersCaption.Location = new System.Drawing.Point(16, 16);
            this.lblPlayersCaption.Name = "lblPlayersCaption";
            this.lblPlayersCaption.Size = new System.Drawing.Size(47, 13);
            this.lblPlayersCaption.TabIndex = 0;
            this.lblPlayersCaption.Text = "Players:";
            // 
            // cmbPlayers
            // 
            this.cmbPlayers.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPlayers.FormattingEnabled = true;
            this.cmbPlayers.Items.AddRange(new object[] { 2, 3, 4 });
            this.cmbPlayers.Location = new System.Drawing.Point(69, 12);
            this.cmbPlayers.Name = "cmbPlayers";
            this.cmbPlayers.Size = new System.Drawing.Size(60, 21);
            this.cmbPlayers.TabIndex = 1;
            this.cmbPlayers.SelectedIndexChanged += new System.EventHandler(this.cmbPlayers_SelectedIndexChanged);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(150, 10);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(110, 25);
            this.btnStart.TabIndex = 2;
            this.btnStart.Text = "Start Game";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnPlay
            // 
            this.btnPlay.Location = new System.Drawing.Point(266, 10);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(110, 25);
            this.btnPlay.TabIndex = 3;
            this.btnPlay.Text = "Play Round";
            this.btnPlay.UseVisualStyleBackColor = true;
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // btnAuto10
            // 
            this.btnAuto10.Location = new System.Drawing.Point(382, 10);
            this.btnAuto10.Name = "btnAuto10";
            this.btnAuto10.Size = new System.Drawing.Size(140, 25);
            this.btnAuto10.TabIndex = 4;
            this.btnAuto10.Text = "Auto 10 Rounds";
            this.btnAuto10.UseVisualStyleBackColor = true;
            this.btnAuto10.Click += new System.EventHandler(this.btnAuto10_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(528, 10);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(90, 25);
            this.btnReset.TabIndex = 5;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // lblName1
            // 
            this.lblName1.AutoSize = true;
            this.lblName1.Location = new System.Drawing.Point(16, 60);
            this.lblName1.Name = "lblName1";
            this.lblName1.Size = new System.Drawing.Size(55, 13);
            this.lblName1.TabIndex = 6;
            this.lblName1.Text = "Player 1:";
            // 
            // txtP1
            // 
            this.txtP1.Location = new System.Drawing.Point(90, 56);
            this.txtP1.Name = "txtP1";
            this.txtP1.Size = new System.Drawing.Size(160, 20);
            this.txtP1.TabIndex = 7;
            this.txtP1.Text = "Player 1";
            // 
            // lblP1
            // 
            this.lblP1.AutoSize = true;
            this.lblP1.Location = new System.Drawing.Point(270, 60);
            this.lblP1.Name = "lblP1";
            this.lblP1.Size = new System.Drawing.Size(70, 13);
            this.lblP1.TabIndex = 8;
            this.lblP1.Text = "Player 1: 0";
            // 
            // lblName2
            // 
            this.lblName2.AutoSize = true;
            this.lblName2.Location = new System.Drawing.Point(16, 92);
            this.lblName2.Name = "lblName2";
            this.lblName2.Size = new System.Drawing.Size(55, 13);
            this.lblName2.TabIndex = 9;
            this.lblName2.Text = "Player 2:";
            // 
            // txtP2
            // 
            this.txtP2.Location = new System.Drawing.Point(90, 88);
            this.txtP2.Name = "txtP2";
            this.txtP2.Size = new System.Drawing.Size(160, 20);
            this.txtP2.TabIndex = 10;
            this.txtP2.Text = "Player 2";
            // 
            // lblP2
            // 
            this.lblP2.AutoSize = true;
            this.lblP2.Location = new System.Drawing.Point(270, 92);
            this.lblP2.Name = "lblP2";
            this.lblP2.Size = new System.Drawing.Size(70, 13);
            this.lblP2.TabIndex = 11;
            this.lblP2.Text = "Player 2: 0";
            // 
            // lblName3
            // 
            this.lblName3.AutoSize = true;
            this.lblName3.Location = new System.Drawing.Point(16, 124);
            this.lblName3.Name = "lblName3";
            this.lblName3.Size = new System.Drawing.Size(55, 13);
            this.lblName3.TabIndex = 12;
            this.lblName3.Text = "Player 3:";
            this.lblName3.Visible = false;
            // 
            // txtP3
            // 
            this.txtP3.Location = new System.Drawing.Point(90, 120);
            this.txtP3.Name = "txtP3";
            this.txtP3.Size = new System.Drawing.Size(160, 20);
            this.txtP3.TabIndex = 13;
            this.txtP3.Text = "Player 3";
            this.txtP3.Visible = false;
            // 
            // lblP3
            // 
            this.lblP3.AutoSize = true;
            this.lblP3.Location = new System.Drawing.Point(270, 124);
            this.lblP3.Name = "lblP3";
            this.lblP3.Size = new System.Drawing.Size(70, 13);
            this.lblP3.TabIndex = 14;
            this.lblP3.Text = "Player 3: 0";
            this.lblP3.Visible = false;
            // 
            // lblName4
            // 
            this.lblName4.AutoSize = true;
            this.lblName4.Location = new System.Drawing.Point(16, 156);
            this.lblName4.Name = "lblName4";
            this.lblName4.Size = new System.Drawing.Size(55, 13);
            this.lblName4.TabIndex = 15;
            this.lblName4.Text = "Player 4:";
            this.lblName4.Visible = false;
            // 
            // txtP4
            // 
            this.txtP4.Location = new System.Drawing.Point(90, 152);
            this.txtP4.Name = "txtP4";
            this.txtP4.Size = new System.Drawing.Size(160, 20);
            this.txtP4.TabIndex = 16;
            this.txtP4.Text = "Player 4";
            this.txtP4.Visible = false;
            // 
            // lblP4
            // 
            this.lblP4.AutoSize = true;
            this.lblP4.Location = new System.Drawing.Point(270, 156);
            this.lblP4.Name = "lblP4";
            this.lblP4.Size = new System.Drawing.Size(70, 13);
            this.lblP4.TabIndex = 17;
            this.lblP4.Text = "Player 4: 0";
            this.lblP4.Visible = false;
            // 
            // lblLogCaption
            // 
            this.lblLogCaption.AutoSize = true;
            this.lblLogCaption.Location = new System.Drawing.Point(16, 196);
            this.lblLogCaption.Name = "lblLogCaption";
            this.lblLogCaption.Size = new System.Drawing.Size(60, 13);
            this.lblLogCaption.TabIndex = 18;
            this.lblLogCaption.Text = "Round Log";
            // 
            // lstRound
            // 
            this.lstRound.FormattingEnabled = true;
            this.lstRound.HorizontalScrollbar = true;
            this.lstRound.Location = new System.Drawing.Point(16, 216);
            this.lstRound.Name = "lstRound";
            this.lstRound.Size = new System.Drawing.Size(760, 264);
            this.lstRound.TabIndex = 19;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(800, 500);
            this.Controls.Add(this.lstRound);
            this.Controls.Add(this.lblLogCaption);
            this.Controls.Add(this.lblP4);
            this.Controls.Add(this.txtP4);
            this.Controls.Add(this.lblName4);
            this.Controls.Add(this.lblP3);
            this.Controls.Add(this.txtP3);
            this.Controls.Add(this.lblName3);
            this.Controls.Add(this.lblP2);
            this.Controls.Add(this.txtP2);
            this.Controls.Add(this.lblName2);
            this.Controls.Add(this.lblP1);
            this.Controls.Add(this.txtP1);
            this.Controls.Add(this.lblName1);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnAuto10);
            this.Controls.Add(this.btnPlay);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.cmbPlayers);
            this.Controls.Add(this.lblPlayersCaption);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "War (Project 3)";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblPlayersCaption;
        private System.Windows.Forms.ComboBox cmbPlayers;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.Button btnAuto10;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label lblName1;
        private System.Windows.Forms.TextBox txtP1;
        private System.Windows.Forms.Label lblP1;
        private System.Windows.Forms.Label lblName2;
        private System.Windows.Forms.TextBox txtP2;
        private System.Windows.Forms.Label lblP2;
        private System.Windows.Forms.Label lblName3;
        private System.Windows.Forms.TextBox txtP3;
        private System.Windows.Forms.Label lblP3;
        private System.Windows.Forms.Label lblName4;
        private System.Windows.Forms.TextBox txtP4;
        private System.Windows.Forms.Label lblP4;
        private System.Windows.Forms.Label lblLogCaption;
        private System.Windows.Forms.ListBox lstRound;
    }
}

