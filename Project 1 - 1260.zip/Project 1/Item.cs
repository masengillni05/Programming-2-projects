﻿using System;
using System.Collections.Generic;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Base class for all items.
/// </summary>
public abstract class Item
{
    public string Name { get; init; } = "";
    public string PickupText { get; init; } = "";

    /// <summary>Called when player picks up the item.</summary>
    /// <param name="player">Receiving player.</param>
    /// <returns>Pickup message.</returns>
    public abstract string OnPickup(Player player);
}
