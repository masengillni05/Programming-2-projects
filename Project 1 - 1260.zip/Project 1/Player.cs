﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;
using System.Collections.Generic;
using System.Linq;

/// <summary>
/// The user-controlled character.
/// </summary>
public sealed class Player : ICharacter
{
    public string Name { get; }
    public int Health { get; private set; }
    public int BaseAttack { get; }                      // gets all player info like health, attack etc...
    public List<Weapon> Inventory { get; } = new();
    public (int Row, int Col) Pos { get; set; }

    public int AttackPower => BaseAttack + (Inventory.Count == 0 ? 0 : Inventory.Max(w => w.AttackModifier));

    public Player(string name, int health = 25, int baseAttack = 3)
    {
        Name = name;
        Health = health;                   // sets up players info
        BaseAttack = baseAttack;
    }

    public void Heal(int amount) => Health += amount;  // computes the heal for player

    public string Attack(ICharacter target)         /// computes the amount of attack given
    {
        int dmg = AttackPower;
        string msg = $"{Name} hits {target.Name} for {dmg}.";
        msg += " " + target.TakeDamage(dmg);
        return msg;
    }

    public string TakeDamage(int amount)   /// computes the amount of damage taken
    {
        Health -= amount;
        if (Health <= 0) return $"{Name} takes {amount} damage and dies!";
        return $"{Name} takes {amount} damage (HP {Health}).";
    }
}
