﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// One cell in the maze.
/// </summary>
public sealed class Tile
{
    public bool IsWall { get; set; } // if cell is maze well
    public bool IsExit { get; set; } // if cell is maze exit
    public Item? Item { get; set; } // if cell is maze item
    public Monster? Monster { get; set; } // if cell is monstor

    public bool IsEmpty => !IsWall && !IsExit && Item is null && Monster is null; //another true statment
}
