﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Weapon that boosts attack.
/// </summary>
public sealed class Weapon : Item
{
    public int AttackModifier { get; init; }  // gets attack modifer 

    public override string OnPickup(Player player)                 // shows the pick up text for player
                                                                  // and adds to the inventory
    {
        player.Inventory.Add(this);
        return PickupText.Length > 0
            ? PickupText
            : $"{player.Name} picked up {Name} (+{AttackModifier}).";
    }
}


