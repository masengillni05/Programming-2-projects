﻿
using System;
using System;
using System.Collections.Generic;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// An enemy that fights the player.
/// </summary>
public sealed class Monster : ICharacter
{
    public string Name { get; } // name for monster 
    public int Health { get; private set; } // health for monster
    public int AttackPower { get; } //attack power for monster
    public (int Row, int Col) Pos { get; set; } // postion for monster 

    public Monster(string name, int health, int attack) // sets up the monster before the game
    {
        Name = name;
        Health = health;
        AttackPower = attack;
    }


    /// <summary>
    /// Performs one attack turn against the 
    /// target and returns a message describing the hit and result.
    /// </summary>
    public string Attack(ICharacter target)
    {
        int dmg = AttackPower;
        string msg = $"{Name} hits {target.Name} for {dmg}.";
        msg += " " + target.TakeDamage(dmg);
        return msg;
    }

    public string TakeDamage(int amount)
    {
        Health -= amount;
        if (Health <= 0) return $"{Name} takes {amount} damage and dies!";
        return $"{Name} takes {amount} damage (HP {Health}).";
    }
}
