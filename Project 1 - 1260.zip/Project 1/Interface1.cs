﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Interface for anything that can battle.
/// </summary>
public interface ICharacter
{
    /// <summary>Display name.</summary>
    string Name { get; }

    /// <summary>Current health.</summary>
    int Health { get; }

    /// <summary>Current attack power.</summary>
    int AttackPower { get; }

    /// <summary>Attacks the target.</summary>
    /// <param name="target">Target to hit.</param>
    /// <returns>Battle message.</returns>
    string Attack(ICharacter target);

    /// <summary>Applies damage.</summary>
    /// <param name="amount">Damage amount.</param>
    /// <returns>Damage message.</returns>
    string TakeDamage(int amount);
}

