﻿using System;
using System.Collections.Generic;

/// <summary>
/// Entry point that runs the game loop and prints to console.
/// </summary>
internal class Program
{
    private static void Main()
    {
        Console.Title = "Project 1 - Adventure Game";
        var rng = new Random();

        var maze = new Maze(12, 24); // You can edit the maze generation grid
        maze.Generate(rng);

        var player = new Player("Hero");
        player.Pos = maze.Start;  /// poston where P starts in the maze

        /// below you can edit the health and damage of the stuff in the game
        maze.GetTile((2, 5)).Item = new Weapon { Name = "Dagger", AttackModifier = 1 };
        maze.GetTile((5, 10)).Item = new Potion { Name = "Small Potion", HealAmount = 5 };
        maze.GetTile((3, 8)).Monster = new Monster("Goblin", 10, 5);

        var log = new Queue<string>();

        while (true)
        {
            Console.Clear();
            Render(maze, player);
            foreach (var line in log) Console.WriteLine(line);
            log.Clear();

            // Input for game controls
            var key = Console.ReadKey(true).Key;
            var delta = key switch
            {
                ConsoleKey.W or ConsoleKey.UpArrow => (-1, 0),
                ConsoleKey.S or ConsoleKey.DownArrow => (1, 0),
                ConsoleKey.A or ConsoleKey.LeftArrow => (0, -1),
                ConsoleKey.D or ConsoleKey.RightArrow => (0, 1),
                _ => (0, 0)
            };
            var next = (player.Pos.Row + delta.Item1, player.Pos.Col + delta.Item2);
            if (!maze.CanMoveTo(next)) continue;

            player.Pos = next;
            var tile = maze.GetTile(player.Pos);

            // Monster battle
            if (tile.Monster is Monster m)
            {
                while (player.Health > 0 && m.Health > 0)
                {
                    log.Enqueue(player.Attack(m));
                    if (m.Health <= 0) { log.Enqueue($"{m.Name} is defeated!"); tile.Monster = null; break; }

                    log.Enqueue(m.Attack(player));
                    if (player.Health <= 0) { log.Enqueue("You died. Game over."); End(); return; }
                }
            }

            // Item pickup
            if (tile.Item is Item item)
            {
                log.Enqueue(item.OnPickup(player));
                tile.Item = null;
            }

            // Exit check
            if (tile.IsExit)
            {
                log.Enqueue("You reached the exit. You win!");
                Console.Clear();
                Render(maze, player);
                foreach (var l in log) Console.WriteLine(l);
                End();
                return;
            }
        }
    }
    /// <summary>
    /// Draws the entire maze to the console using # . P M W ! E and prints the legend.
    /// </summary>
    private static void Render(Maze maze, Player player)
    {
        for (int r = 0; r < maze.Rows; r++)
        {
            for (int c = 0; c < maze.Cols; c++)
            {
                if (player.Pos == (r, c)) { Console.Write('P'); continue; }

                var t = maze.GetTile((r, c));
                if (t.IsWall) Console.Write('#');
                else if (t.IsExit) Console.Write('E');
                else if (t.Monster is not null) Console.Write('M');
                else if (t.Item is Weapon) Console.Write('W');
                else if (t.Item is Potion) Console.Write('!');
                else Console.Write('.');
            }
            Console.WriteLine();
        }
        Console.WriteLine("legend: # wall  . floor  P you  M monster  W weapon  ! potion  E exit");
    }
    /// <summary>
    /// Shows a closing prompt and waits for a key before exiting.
    /// </summary>
    private static void End()
    {
        Console.WriteLine();
        Console.WriteLine("Press any key to exit...");
        Console.ReadKey(true);
    }
}
