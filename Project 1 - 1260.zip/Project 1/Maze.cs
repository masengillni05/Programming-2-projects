﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;

/// <summary>
/// 2D grid with walls, items, monsters, and exit.
/// </summary>
public sealed class Maze
{
    public Tile[,] Grid { get; }
    public (int Row, int Col) Start { get; private set; }     // gets the int for the columns/rows when 
                                                              // generating the maze also grabs from the tile class.
    public (int Row, int Col) Exit { get; private set; }
    public int Rows => Grid.GetLength(0);
    public int Cols => Grid.GetLength(1);

    public Maze(int rows, int cols)
    {
        Grid = new Tile[rows, cols];
        for (int r = 0; r < rows; r++)
            for (int c = 0; c < cols; c++)
                Grid[r, c] = new Tile();
        Start = (1, 1);
        Exit = (rows - 2, cols - 2);
    }

    public bool CanMoveTo((int Row, int Col) p)   /// returns if true for movement but only if its targeted
        => p.Row >= 0 && p.Row < Rows && p.Col >= 0 && p.Col < Cols && !Grid[p.Row, p.Col].IsWall;

    public Tile GetTile((int Row, int Col) p) => Grid[p.Row, p.Col];  // given a cordinate it returns a tile 
                                                                     //stored in the array 

    public void Generate(Random rng) /// it randomize the maze build and can overide any layouts and also can place the monsters
    {
        // Border walls
        for (int r = 0; r < Rows; r++)
        {
            Grid[r, 0].IsWall = true;
            Grid[r, Cols - 1].IsWall = true;
        }                                                 // code to set the grid walls etc
        for (int c = 0; c < Cols; c++)
        {
            Grid[0, c].IsWall = true;
            Grid[Rows - 1, c].IsWall = true;
        }

        Start = (1, 1);
        Exit = (Rows - 2, Cols - 2);                                 /// same thing here
        Grid[Exit.Row, Exit.Col].IsExit = true;

        // Random inner walls
        for (int r = 1; r < Rows - 1; r++)
            for (int c = 1; c < Cols - 1; c++)
                if ((r, c) != Start && (r, c) != Exit && rng.NextDouble() < 0.20)
                    Grid[r, c].IsWall = true;

        // Carve simple guaranteed corridor
        for (int c = Start.Col; c <= Exit.Col; c++) Grid[Start.Row, c].IsWall = false;
        for (int r = Start.Row; r <= Exit.Row; r++) Grid[r, Exit.Col].IsWall = false;
    }
}

