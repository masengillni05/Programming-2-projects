﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Potion that heals on pickup.
/// </summary>
public sealed class Potion : Item
{
    public int HealAmount { get; init; } // gets heal amount

    public override string OnPickup(Player player) /// computes health amount and displays a text once 
                                                   /// picked up.
    {
        player.Heal(HealAmount);
        return PickupText.Length > 0
            ? PickupText
            : $"{player.Name} drank {Name} (+{HealAmount} HP).";
    }
}
