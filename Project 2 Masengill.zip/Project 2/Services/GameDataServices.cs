﻿using AdventureGame;

namespace GameManual.Services
{
    /// <summary>
    /// This service holds all of the game’s data in one place.
    /// It provides lists of players, monsters, and items that can be displayed in the Blazor pages.
    /// </summary>
    public class GameDataService
    {
        // Used to refresh image files in the browser when you swap them out.
        // Changing this number forces the browser to reload new images instead of using cached ones.
        private const string CacheBust = "?v=3";

        // Collections of the main game objects.
        public List<Player> Players { get; }
        public List<Monster> Monsters { get; }
        public List<Item> Items { get; }

        /// <summary>
        /// Sets up the game data when the service is first created.
        /// This includes one player, one monster, and a few sample items to display.
        /// </summary>
        public GameDataService()
        {
            // Player list — currently just one main hero for display purposes.
            Players = new()
            {
                new Player("Hero")
                {
                    Id = 1,
                    ImageUrl = "/images/Hero.png" + CacheBust,
                    Description = "The player-controlled hero and main character of the game.",
                    Type = "Player"
                }
            };

            // Monster list — currently includes a single goblin example.
            Monsters = new()
            {
                new Monster("Goblin", 8, 2)
                {
                    Id = 2,
                    ImageUrl = "/images/Goblin.png" + CacheBust,
                    Description = "A weak creature found wandering the maze, often near the center.",
                    Type = "Monster"
                }
            };

            // Item list — contains both a weapon and a potion example.
            Items = new()
            {
                new Weapon
                {
                    Id = 1,
                    Name = "Dagger",
                    AttackModifier = 1,
                    ImageUrl = "/images/Dagger.png" + CacheBust,
                    Description = "A small, light weapon that gives a minor attack boost.",
                    Type = "Weapon"
                },
                new Potion
                {
                    Id = 2,
                    Name = "Small Potion",
                    HealAmount = 5,
                    ImageUrl = "/images/Potion.png" + CacheBust,
                    Description = "A basic potion that restores a small amount of health.",
                    Type = "Potion"
                }
            };
        }

        /// <summary>
        /// Finds and returns a player by their ID number.
        /// </summary>
        public Player? GetPlayerById(int id) => Players.FirstOrDefault(p => p.Id == id);

        /// <summary>
        /// Finds and returns a monster by its ID number.
        /// </summary>
        public Monster? GetMonsterById(int id) => Monsters.FirstOrDefault(m => m.Id == id);

        /// <summary>
        /// Finds and returns an item by its ID number.
        /// </summary>
        public Item? GetItemById(int id) => Items.FirstOrDefault(i => i.Id == id);
    }
}
