﻿using System.Text.Json;

namespace GameManual.Services
{
    /// <summary>
    /// Saves and loads the player's notes to a JSON file
    /// inside their local AppData folder so the notes stay saved
    /// even after the app closes.
    /// </summary>
    public class NotesService
    {
        // Full file path where notes will be saved
        private readonly string _filePath;

        // Keeps file operations thread-safe (only one at a time)
        private readonly SemaphoreSlim _gate = new(1, 1);

        // Stores the current notes text in memory
        private string _text = string.Empty;

        // Tracks if the notes have already been loaded from disk
        private bool _loaded;

        // Simple record used to wrap our notes text for JSON saving
        private record Payload(string Text);

        // Constructor - sets up the save location in LocalAppData
        public NotesService()
        {
            // Example path: C:\Users\<User>\AppData\Local\GameManual\notes.json
            var root = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var dir = Path.Combine(root, "GameManual");
            Directory.CreateDirectory(dir); // create folder if missing
            _filePath = Path.Combine(dir, "notes.json");
        }

        /// <summary>
        /// Loads the notes text from file if it hasn't been loaded yet
        /// and returns the current notes string.
        /// </summary>
        public async Task<string> GetAsync(CancellationToken ct = default)
        {
            await EnsureLoadedAsync(ct);
            return _text;
        }

        /// <summary>
        /// Updates the in-memory notes and saves them to the JSON file.
        /// </summary>
        public async Task SetAndSaveAsync(string text, CancellationToken ct = default)
        {
            // Wait in case another save/load is happening
            await _gate.WaitAsync(ct);
            try
            {
                // Replace null text with empty string
                _text = text ?? string.Empty;

                // Convert the text into JSON
                var json = JsonSerializer.Serialize(new Payload(_text),
                    new JsonSerializerOptions { WriteIndented = true });

                // Write the JSON to disk
                await File.WriteAllTextAsync(_filePath, json, ct);
            }
            finally
            {
                // Always release the lock so others can save
                _gate.Release();
            }
        }

        /// <summary>
        /// Loads the notes from disk once when first accessed.
        /// If the file is missing or corrupt, it starts with a blank note.
        /// </summary>
        private async Task EnsureLoadedAsync(CancellationToken ct)
        {
            // Skip if already loaded
            if (_loaded) return;

            await _gate.WaitAsync(ct);
            try
            {
                if (_loaded) return;

                if (File.Exists(_filePath))
                {
                    try
                    {
                        // Read the file and pull the text back out
                        var json = await File.ReadAllTextAsync(_filePath, ct);
                        var payload = JsonSerializer.Deserialize<Payload>(json);
                        _text = payload?.Text ?? string.Empty;
                    }
                    catch
                    {
                        // If file couldn't be read, start fresh
                        _text = string.Empty;
                    }
                }

                // Mark as loaded so we don't re-read the file later
                _loaded = true;
            }
            finally
            {
                _gate.Release();
            }
        }
    }
}
