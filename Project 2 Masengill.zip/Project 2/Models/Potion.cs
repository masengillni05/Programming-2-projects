﻿/// <summary>
/// Represents a potion item that restores health.
/// </summary>
public class Potion : Item
{
    /// <summary>
    /// Amount of health restored.
    /// </summary>
    public int HealAmount { get; set; }

    public override string OnPickup(Player player)
    {
        // Safely call Heal() inside the Player class
        player.Heal(HealAmount);
        return $"{player.Name} used {Name} and restored {HealAmount} HP!";
    }
}


