﻿/// <summary>
/// Represents a weapon item that increases attack.
/// </summary>
public class Weapon : Item
{
    /// <summary>
    /// How much extra damage the weapon adds.
    /// </summary>
    public int AttackModifier { get; set; }

    public override string OnPickup(Player player)
        => $"{player.Name} picked up {Name} and gained +{AttackModifier} attack!";
}

