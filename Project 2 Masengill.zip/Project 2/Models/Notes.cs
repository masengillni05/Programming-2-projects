﻿namespace GameManual.Models
{
    /// <summary>
    /// A single note the user creates in the manual.
    /// Notes can also include "references" to a character or item.
    /// </summary>
    public class Note
    {
        /// <summary>
        /// Simple running ID so we can edit/delete specific notes.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// A short title to quickly identify the note.
        /// </summary>
        public string Title { get; set; } = "";

        /// <summary>
        /// The main text body of the note.
        /// </summary>
        public string Body { get; set; } = "";

        /// <summary>
        /// Optional links from this note to characters/items in the manual.
        /// </summary>
        public List<NoteReference> References { get; set; } = new();
    }

    /// <summary>
    /// A link from a note to either a character or an item.
    /// Clicking it should navigate to that thing’s details page.
    /// </summary>
    public class NoteReference
    {
        /// <summary>
        /// Either "Character" or "Item". Kept as a string to keep it simple.
        /// </summary>
        public string Kind { get; set; } = "";

        /// <summary>
        /// The ID of the referenced character or item.
        /// </summary>
        public int TargetId { get; set; }

        /// <summary>
        /// A friendly label to show in the UI (e.g., the name).
        /// </summary>
        public string Label { get; set; } = "";
    }
}

