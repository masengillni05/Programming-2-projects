﻿namespace AdventureGame;

/// <summary>
/// An AI-controlled enemy with simple attack/health stats.
/// </summary>
public class Monster 
{
    /// <inheritdoc/>
    public string Name { get; }

    /// <inheritdoc/>
    public int Health { get; private set; }

    /// <inheritdoc/>
    public int BaseAttack { get; }

    /// <inheritdoc/>
    public bool IsDead => Health <= 0;

    /// <summary>
    /// Create a monster with name, HP, and base attack.
    /// </summary>
    public Monster(string name, int hp = 8, int baseAttack = 2)
    {
        Name = name;
        Health = hp;
        BaseAttack = baseAttack;
    }

    /// <inheritdoc/>
    public int DealDamage() => BaseAttack;

    /// <inheritdoc/>
    public void TakeDamage(int amount)
    {
        if (amount < 0) amount = 0;
        Health -= amount;
    }

    // === Manual metadata for Project 2 (new) ===

    /// <summary>Unique ID used for routing in the Blazor manual.</summary>
    public int Id { get; set; }

    /// <summary>URL path to the monster's image (stored in wwwroot/images).</summary>
    public string ImageUrl { get; set; } = "images/goblin.png";

    /// <summary>Short description shown in the manual.</summary>
    public string Description { get; set; } = "A hostile creature found in the maze.";

    /// <summary>Type grouping for the manual (used to group Monsters vs Player).</summary>
    public string Type { get; set; } = "Monster";
}
