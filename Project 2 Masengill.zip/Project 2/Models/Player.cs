﻿
using System;
using System.Collections.Generic;
using System.Linq;

/// <summary>
/// The user-controlled character.
/// </summary>                                        //This is also my porject 1 code.
public sealed class Player 
{
    public string Name { get; }
    public int Health { get; private set; }
    public int BaseAttack { get; }
    public List<Weapon> Inventory { get; } = new();
    public (int Row, int Col) Pos { get; set; }

    public int AttackPower => BaseAttack + (Inventory.Count == 0 ? 0 : Inventory.Max(w => w.AttackModifier));

    public Player(string name, int health = 25, int baseAttack = 3)
    {
        Name = name;
        Health = health;
        BaseAttack = baseAttack;
    }

    public void Heal(int amount) => Health += amount;

    public string Attack(ICharacter target)
    {
        int dmg = AttackPower;
        string msg = $"{Name} hits {target.Name} for {dmg}.";
        msg += " " + target.TakeDamage(dmg);
        return msg;
    }

    public string TakeDamage(int amount)
    {
        Health -= amount;
        if (Health <= 0) return $"{Name} takes {amount} damage and dies!";
        return $"{Name} takes {amount} damage (HP {Health}).";
    }

    // These are new bits of code I added to improve the fuctionality with the website.
    public int Id { get; set; } = 1;
    public string ImageUrl { get; set; } = "images/hero.png";
    public string Description { get; set; } = "The main hero controlled by the player.";
    public string Type { get; set; } = "Player";
}
