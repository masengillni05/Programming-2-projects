﻿using System;

/// <summary>
/// Base class for all items.
/// </summary>
public abstract class Item
{
    public string Name { get; init; } = "";
    public string PickupText { get; init; } = "";

    /// <summary>
    /// Called when the player picks up the item.
    /// </summary>
    /// <param name="player">Receiving player.</param>
    /// <returns>Pickup message.</returns>
    public abstract string OnPickup(Player player);

    // === Manual metadata for Project 2 ===

    /// <summary>Unique ID used for routing in the Blazor manual.</summary>
    public int Id { get; set; }

    /// <summary>URL path to the item's image (stored in wwwroot/images).</summary>
    public string ImageUrl { get; set; } = "";

    /// <summary>Short description shown in the manual.</summary>
    public string Description { get; set; } = "";

    /// <summary>Type grouping for the manual (used to categorize items).</summary>
    public string Type { get; set; } = "";
}

