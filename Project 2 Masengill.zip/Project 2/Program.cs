﻿using Project_2.Components;
using GameManual.Services;

// Make a new web app
var builder = WebApplication.CreateBuilder(args);

// Add services that stay running while the app is open
builder.Services.AddSingleton<GameDataService>(); // holds game data
builder.Services.AddSingleton<NotesService>();    // handles saving notes

// Set up Blazor pages
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// Build the app
var app = builder.Build();

// If not running in debug mode, handle errors safely
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts(); // helps keep connections secure
}

// Set up normal web features
app.UseHttpsRedirection(); // go to HTTPS
app.UseStaticFiles();      // load images, CSS, etc.
app.UseAntiforgery();      // security for forms

// Tell the app to start with the main Blazor file (App.razor)
app.MapRazorComponents<App>()
   .AddInteractiveServerRenderMode();

// Run the app
app.Run();
